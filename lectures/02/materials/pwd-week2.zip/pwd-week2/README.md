# SvelteKit 프로젝트 Vercel 배포 실습 가이드

2026학년도 2학기 · 2주차 실습 (갱신 기준: 2026-09-14)

## 실습 개요

이번 실습에서는 SvelteKit 웹 프레임워크 안에서 HTML, CSS, JavaScript를 함께 사용해 간단한 자기소개 웹사이트를 만들고, GitHub를 통해 코드를 관리하며, Vercel로 배포하는 과정을 경험합니다.

### 학습 목표
- Node.js와 npm 환경 구축
- SvelteKit 프레임워크에서 HTML, CSS, JavaScript를 활용한 웹사이트 제작
- Git/GitHub를 활용한 버전 관리
- Vercel을 통한 자동 배포 파이프라인 구축

### 소요 시간
약 2-3시간

---

## Step 1: Node.js 설치 및 환경 설정

### 1.1 Node.js 다운로드 및 설치

1. [Node.js 공식 사이트](https://nodejs.org) 접속
2. **Node.js 24 LTS** 다운로드 (2026년 2학기 실습 기준, npm 포함)
3. 운영체제별 설치:
   - **Windows**: 다운로드한 .msi 파일 실행 → Next 클릭하며 기본 설정으로 설치
   - **Mac**: 다운로드한 .pkg 파일 실행 → 설치 마법사 따라 진행

### 1.2 설치 확인

터미널(Windows는 명령 프롬프트 또는 PowerShell)을 열고 다음 명령어로 설치 확인:

```bash
node -v
# v24.x.x 형태로 버전 출력되면 성공

npm -v
# 설치된 npm 버전이 출력되면 성공 (Node.js 24에 포함된 npm 사용)
```

> ⚠️ **오류 해결**: 명령어를 찾을 수 없다고 나오는 경우 터미널 재시작 후 다시 시도

> 버전 기준: [Node.js 공식 릴리스 안내](https://nodejs.org/en/about/previous-releases). 로컬과 Vercel 모두 Node.js 24를 사용합니다.

## Step 2: SvelteKit 프로젝트 생성

### 2.1 프로젝트 생성

```bash
# 작업할 폴더 생성 후 이동 (이미 있다면 cd 명령만 실행)
mkdir Workspace
cd Workspace

# SvelteKit 프로젝트 초기화 (2026년 2학기 기준 CLI)
npx sv@0.17.0 create pwd-week2
```

설치 확인 질문이 나오면 `y`를 입력하고 다음과 같이 선택합니다. 방향키로 이동하고, 여러 항목은 Space로 선택한 뒤 Enter로 진행합니다.

| 항목 | 선택 |
| --- | --- |
| 프로젝트 템플릿 | SvelteKit minimal |
| 타입 검사 방식 | JavaScript with JSDoc comments |
| 추가 도구 | prettier, eslint, vitest, playwright |
| Vitest 용도 (질문이 표시되는 경우) | unit testing, component testing |
| 패키지 관리자 | npm |

화면 문구나 항목 순서는 달라질 수 있습니다. 위 항목 외에는 기본값을 사용합니다. [Svelte CLI 공식 안내](https://svelte.dev/docs/cli/sv-create)

### 2.2 개발 서버 실행 테스트

```bash
cd pwd-week2
npm run dev -- --open
```

브라우저에서 `http://localhost:5173` 접속하여 SvelteKit 기본 페이지 확인
- SvelteKit 기본 페이지가 보이면 성공!
- 종료: 터미널에서 `Ctrl + C` 누르기

---

## Step 3: GitHub 저장소 생성

### 3.1 GitHub 계정 생성 (이미 있다면 스킵)

1. [GitHub](https://github.com) 접속
2. Sign up 클릭 → 이메일, 비밀번호, 사용자명 입력
3. 이메일 인증 완료

### 3.2 새 저장소 생성

1. GitHub 로그인 후 우측 상단 `+` 버튼 클릭
2. `New repository` 선택
3. 저장소 설정:
   - **Repository name**: `pwd-week2` (프로젝트명과 동일하게)
   - **Description**: "나의 포트폴리오 웹사이트" (선택사항)
   - **Public** 선택 (실습 결과 공유용)
4. `Create repository` 클릭

> 개인 계정의 Private 저장소도 Vercel에 배포할 수 있습니다. 조직 소유 Private 저장소는 Hobby 플랜에서 제한됩니다. [Vercel Git 연동 안내](https://vercel.com/docs/git)

### 3.3 생성된 저장소 URL 복사

생성 후 나타나는 페이지에서 HTTPS URL 복사:
```
https://github.com/[your-username]/pwd-week2.git
```

---

## Step 4: 로컬 프로젝트와 GitHub 저장소 연동

### 4.1 Git 초기화 및 첫 커밋

프로젝트 폴더(pwd-week2)에서 터미널 실행:

```bash
# Git 저장소 초기화
git init

# 모든 파일을 스테이징
git add .

# 첫 번째 커밋
git commit -m "Initial commit: SvelteKit 프로젝트 생성"
```

### 4.2 GitHub 저장소 연결

```bash
# 브랜치 이름을 main으로 변경 (필요한 경우)
git branch -M main

# 원격 저장소 추가 (복사한 URL 사용)
git remote add origin https://github.com/[username]/pwd-week2.git

# GitHub에 푸시
git push -u origin main
```

### 4.3 연동 확인

GitHub 저장소 페이지 새로고침하여 파일들이 업로드되었는지 확인

---

## Step 5: SvelteKit 프로젝트 코드 작성

### 5.1 프로젝트 구조
```
src/
├─ app.css
├─ lib/
│  └─ Card.svelte
└─ routes/
   ├─ +layout.svelte
   ├─ +page.svelte            # /
   ├─ about/
   │  └─ +page.svelte         # /about
   ├─ api/
   │  └─ projects/
   │     └─ +server.js        # GET /api/projects
   └─ projects/
      ├─ +page.js             # /projects (load)
      ├─ +page.svelte         # /projects (view)
      └─ [slug]/
         ├─ +page.server.js   # /projects/[slug] (server load)
         └─ +page.svelte      # /projects/[slug] (view)
```

### 5.2 전역 스타일(CSS)
```css
/* src/app.css */
:root { --brand: #5b3df5; }
* { box-sizing: border-box; }
body { margin:0; font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif; line-height: 1.6; color:#222; }
a { color: var(--brand); text-decoration: none; }
nav { display:flex; gap:1rem; padding:1rem; border-bottom:1px solid #eee; }
main { max-width: 880px; margin: 2rem auto; padding: 0 1rem; }
.card { border:1px solid #eee; border-radius: 12px; padding:1rem; margin:.5rem 0; }
```

### 5.2 전역 레이아웃
```svelte
<!-- src/routes/+layout.svelte -->
<script>  
  let { children } = $props();
</script>

<svelte:head>
  <title>AJOU Mini Portfolio</title>
  <meta name="description" content="SvelteKit + Vercel mini portfolio" />
</svelte:head>

<nav>
  <a href="/">Home</a>
  <a href="/about">About</a>
  <a href="/projects">Projects</a>
</nav>

<main>
  {@render children()}
</main>

<style global>
  @import '../app.css';
</style>
```

### 5.3 Home: 상태/파생값/바인딩/이벤트 학습
```svelte
<!-- src/routes/+page.svelte -->
<script>
  let name = $state('');
  let welcome = $derived(name ? `Hello, ${name}!` : 'Welcome!');

  function randomize() {
    const msgs = ['웹 개발 재밌다!', 'SvelteKit 금방 익힘', 'Vercel로 바로 배포!'];
    alert(msgs[Math.floor(Math.random() * msgs.length)]);
  }
</script>

<h1>{welcome}</h1>

<label>
  Your name: <input placeholder="type your name" bind:value={name} />
</label>
<p>미리보기: <strong>{name || '(입력 대기)'}</strong></p>

<button onclick={randomize}>랜덤 메시지</button>
```
### 5.4 About: 시맨틱 마크업 학습
```svelte
<!-- src/routes/about/+page.svelte -->
<section class="card">
  <h2>About this site</h2>
  <p>이 사이트는 SvelteKit 기본기와 배포를 연습하기 위한 미니 포트폴리오입니다.</p>
  <ul>
    <li>Semantic HTML</li>
    <li>Routing(정적/동적)</li>
    <li>State / Derived / Effects</li>
    <li>API Route</li>
  </ul>
</section>
```
### 5.5 컴포넌트 & Props 학습
```svelte
<!-- src/lib/Card.svelte -->
<script>
  let { title, summary, href } = $props();
</script>

<article class="card">
  <h3><a href={href}>{title}</a></h3>
  <p>{summary}</p>
</article>
```

### 5.6 프로젝트 목록 API 라우트(서버 개발) 학습
```js
// src/routes/api/projects/+server.js
import { json } from '@sveltejs/kit';

const projects = [
  { slug:'timetable', title:'Timetable Helper', summary:'수업/일정 정리 도우미' },
  { slug:'gallery',   title:'Image Gallery',    summary:'미니 이미지 갤러리' },
  { slug:'memo',      title:'Memo Pad',         summary:'로컬에 메모 저장' }
];

export function GET() {
  return json(projects);
}
```
### 5.7 목록 페이지: API 소비
```js
// src/routes/projects/+page.js
export async function load({ fetch }) {
  const res = await fetch('/api/projects');
  return { projects: await res.json() };
}
```

```svelte
<!-- src/routes/projects/+page.svelte -->
<script>
  import Card from '$lib/Card.svelte';
  let { data } = $props(); // { projects }
</script>

<h2>Projects</h2>
{#each data.projects as p}
  <Card title={p.title} summary={p.summary} href={`/projects/${p.slug}`} />
{:else}
  <p class="card">아직 등록된 프로젝트가 없습니다.</p>
{/each}
```

### 5.8 동적 라우트 상세 + 이펙트 활용 학습
1. 서버에서 상세 데이터 제공
```js
// src/routes/projects/[slug]/+page.server.js
import { error } from '@sveltejs/kit';

const DB = {
  timetable: { title:'Timetable Helper', body:'나만의 시간표를 정리하는 도구입니다.' },
  gallery:   { title:'Image Gallery',    body:'미니 갤러리 예시입니다.' },
  memo:      { title:'Memo Pad',         body:'브라우저 로컬에 메모를 저장/복원합니다.' }
};

export function load({ params }) {
  const key = params.slug;
  const item = DB[key];   // key가 없으면 undefined
  if (!item) throw error(404, 'Not found');
  return { item, slug: key };
}
```

2. 페이지에서 표시 + $effect 로컬 동기화
```svelte
<!-- src/routes/projects/[slug]/+page.svelte -->
<script>
  let { data } = $props();      // { item, slug }
  let memo = $state('');

  // memo 상세에서만 로컬스토리지 동기화
  $effect(() => {
    if (data.slug === 'memo') {
      const saved = localStorage.getItem('memo');
      if (saved) memo = saved;
    }
  });

  function save() {
    localStorage.setItem('memo', memo);
    alert('저장 완료!');
  }
</script>

<h2>{data.item.title}</h2>
<p>{data.item.body}</p>

{#if data.slug === 'memo'}
  <textarea rows="6" bind:value={memo} class="card" style="width:100%"></textarea>
  <button onclick={save}>메모 저장</button>
  <p style="opacity:.6">브라우저 로컬에만 저장됩니다.</p>
{/if}
```
---

## Step 6: Github 커밋 & 푸시
```bash
git add .
git commit -m "feat: mini-portfolio"
git push origin main
```
---

## Step 7: Vercel 배포

### 7.1 Vercel 계정 생성

1. [Vercel](https://vercel.com) 접속
2. `Sign Up` 클릭
3. **Continue with GitHub** 선택 (GitHub 계정으로 로그인)
4. GitHub 권한 승인

### 7.2 새 프로젝트 Import

1. Vercel 대시보드에서 `Add New...` → `Project` 클릭
2. GitHub 저장소 목록에서 `pwd-week2` 찾기
3. 저장소 옆 `Import` 버튼 클릭

### 7.3 프로젝트 설정

Import 페이지에서 다음 설정 확인:

- **Project Name**: pwd-week2 (자동 입력됨)
- **Framework Preset**: SvelteKit (자동 감지됨)
- **Root Directory**: ./ (`package.json`이 저장소 루트에 있는 경우)
- **Build Command**: `npm run build` (자동 설정)
- **Output Directory**: SvelteKit 자동 설정 유지 (직접 입력하지 않음)
- **Install Command**: 패키지 관리자 자동 감지 설정 유지
- **Node.js Version**: `24.x` (`package.json`의 `engines.node`와 동일)

환경 변수는 현재 필요없으므로 그대로 두고 `Deploy` 클릭

설정 화면의 명칭은 변경될 수 있습니다. [Vercel 빌드 설정](https://vercel.com/docs/builds/configure-a-build), [Node.js 버전 설정](https://vercel.com/docs/functions/runtimes/node-js/node-js-versions)

### 7.4 배포 진행 확인

1. 배포가 시작되면 실시간 로그 확인 가능
2. 일반적으로 1-3분 내 완료
3. "Congratulations!" 메시지와 함께 배포 완료

### 7.5 배포된 사이트 확인

- 대시보드에서 제공된 `.vercel.app` URL 클릭
- 사이트가 정상적으로 표시되는지 확인

> 💡 **제출할 URL**: 대시보드에서 프로젝트의 **Production URL**을 복사합니다.
> - 프로젝트명과 계정에 따라 실제 주소가 달라집니다.
> - Production URL은 현재 운영 배포를 가리키며, 고유 배포 URL은 특정 배포를 가리킵니다. [Vercel URL 안내](https://vercel.com/docs/deployments/generated-urls)

### 7.6 자동 배포 테스트

Vercel의 Production Branch가 `main`으로 설정되어 있으면 GitHub main 브랜치에 푸시할 때마다 자동으로 재배포됩니다:

```bash
# 테스트: 작은 변경 후 푸시
echo "# 자동 배포 테스트" >> README.md
git add README.md
git commit -m "test: 자동 배포 확인"
git push origin main
```

Vercel 대시보드에서 새 배포가 시작되는 것 확인

---

## ✅ 과제 제출 체크리스트

### 필수 제출 항목
- [ ] GitHub 저장소 URL
- [ ] Vercel 배포 URL (7.5에서 확인한 Production URL)

### 평가 기준
- [ ] GitHub 저장소에 프로젝트 버전 관리가 바르게 되고 있는가?
- [ ] Vercel에 GitHub 저장소가 연결되어 자동 배포가 이루어 지고 있는가?
- [ ] Vercel 배포한 웹서비스에서 제시한 프로젝트 코드가 모두 바르게 동작하는가? (Home, About, Projects)

### 기능 확장 
- 추가적인 콘텐츠나 기능 확장은 자율적으로 진행하면 됩니다.
- 좋은 실습 결과물들은 강의 시간에 함께 리뷰하도록 하겠습니다.
---

## 🔍 자주 발생하는 문제와 해결법

### Q1. npm 명령어를 찾을 수 없다고 나옵니다

**A:** Node.js가 제대로 설치되지 않았거나 PATH 설정 문제입니다.
- 터미널을 다시 열고 `node -v`, `npm -v`를 확인합니다. 계속 찾을 수 없다면 Node.js 24 LTS를 다시 설치합니다.
- Windows PowerShell에서 `npm.ps1` 실행 정책 오류가 나오는 경우에는 `npm.cmd`, `npx.cmd`를 사용합니다.
```powershell
npm.cmd -v
npx.cmd sv@0.17.0 create pwd-week2
```

### Q2. GitHub 푸시 시 인증 오류가 발생합니다

**A:** GitHub 계정 비밀번호로는 HTTPS push 인증을 할 수 없습니다.
1. Git Credential Manager가 표시하는 브라우저 로그인으로 GitHub에 인증합니다. Git for Windows 설치 시 함께 설치할 수 있습니다.
2. 토큰을 직접 사용해야 한다면 GitHub Settings → Developer settings → Personal access tokens에서 fine-grained token을 만들고, 해당 실습 저장소의 Contents 읽기·쓰기 권한을 지정합니다.
3. Git이 비밀번호를 요청할 때 계정 비밀번호 대신 토큰을 사용합니다.

[GitHub 인증 안내](https://docs.github.com/en/get-started/git-basics/caching-your-github-credentials-in-git)

### Q3. Vercel 배포가 실패합니다

**A:** Build 로그 확인하여 오류 메시지 체크:
- `package.json` 파일이 저장소 루트에 있는지 확인
- 모든 파일이 GitHub에 푸시되었는지 확인
- Node.js 버전 호환성 문제일 경우 로컬과 Vercel 설정이 모두 Node.js 24인지 확인

### Q4. 로컬에서는 작동하는데 배포 후 오류가 발생합니다

**A:** 대소문자 구분 문제일 가능성이 높음:
- Windows는 대소문자 구분 안 함, Vercel(Linux)은 구분함
- 파일명과 import 구문의 대소문자가 정확히 일치하는지 확인

---

## 📚 추가 학습 자료

### 공식 문서
- [SvelteKit 공식 문서](https://svelte.dev/docs/kit)
- [Vercel 문서](https://vercel.com/docs)
- [Git 기초 가이드](https://git-scm.com/book/ko/v2)

### 유용한 VS Code 확장 프로그램
- Svelte for VS Code: Svelte 문법 하이라이팅
- GitLens: Git 히스토리 시각화
- Prettier: 코드 자동 포맷팅
- Thunder Client: API 테스트 도구

---

## 🎯 실습 완료!

축하합니다! 여러분은 이제:
- ✅ Node.js 환경을 구축했습니다
- ✅ SvelteKit 프로젝트를 생성했습니다
- ✅ Git/GitHub로 버전 관리를 시작했습니다
- ✅ 실제 웹사이트를 인터넷에 배포했습니다

이것은 웹 개발자로서의 첫 걸음입니다. 계속해서 기능을 추가하고 개선해나가세요!

---

## 💡 추가 정보: 도메인 연결 (선택사항)

Vercel의 기본 `.vercel.app` 도메인으로 충분하지만, 커스텀 도메인을 연결하고 싶다면:

1. **도메인 구매**
   - Cafe24, Gabia 도메인 구매 (국내 )
   - GoDaddy 도메인 구매 (해외)
   
2. **연결 방법**
   - Vercel 대시보드 → Settings → Domains
   - 도메인 추가 후 DNS 설정
   - 자동 HTTPS 인증서 발급

> 📌 **참고**: 이 부분은 개인적으로 진행하시면 됩니다. 수업에서는 Vercel 기본 도메인으로 충분합니다!
